const DATA_SOURCE = 'data/fake_children.json';

let children = [];
let filteredChildren = [];
let selectedId = null;

const fallbackChildren = [
  {
    id: 'FB-2026-0000', name: 'نور الحسن', age: 10, gender: 'أنثى', country: 'الأردن', city: 'المفرق', location: 'مخيم الزعتري', guardian: 'الأم', phone: '+962-79-0000000', schoolStatus: 'خارج المدرسة',
    education: { literacyScore: 38, mathScore: 42, aiLevel: 'مبتدئ', lastLesson: 'الحروف والقراءة المبكرة', progress: 24, attendanceSessions: 3, recommendation: 'جلسات قراءة مكثفة' },
    health: { eye: 'احمرار خفيف', skin: 'طبيعي', nutrition: 'نقص وزن محتمل', riskLevel: 'متوسط', referralNeeded: true, lastCheck: '2026-05-10' },
    documentation: { consent: true, documents: 'وثائق ناقصة', digitalFile: 'بحاجة مراجعة', qrToken: 'QR-NB20260000' },
    notes: 'بيان احتياطي يظهر فقط إذا لم يعمل ملف JSON.'
  }
];

const els = {
  statsGrid: document.getElementById('statsGrid'),
  table: document.getElementById('childrenTable'),
  detail: document.getElementById('childDetail'),
  resultCount: document.getElementById('resultCount'),
  searchInput: document.getElementById('searchInput'),
  locationFilter: document.getElementById('locationFilter'),
  schoolFilter: document.getElementById('schoolFilter'),
  riskFilter: document.getElementById('riskFilter'),
  resetFilters: document.getElementById('resetFilters'),
  exportCsvBtn: document.getElementById('exportCsvBtn'),
  openAddModal: document.getElementById('openAddModal'),
  closeAddModal: document.getElementById('closeAddModal'),
  addModal: document.getElementById('addModal'),
  addChildForm: document.getElementById('addChildForm')
};

async function init() {
  try {
    if (Array.isArray(window.NOORBUS_DATA) && window.NOORBUS_DATA.length) {
      children = window.NOORBUS_DATA;
    } else {
      const response = await fetch(DATA_SOURCE);
      if (!response.ok) throw new Error('تعذر تحميل البيانات');
      children = await response.json();
    }
  } catch (error) {
    console.warn('Using fallback data:', error);
    children = fallbackChildren;
  }

  filteredChildren = [...children];
  fillFilters();
  bindEvents();
  render();
}

function bindEvents() {
  [els.searchInput, els.locationFilter, els.schoolFilter, els.riskFilter].forEach(input => {
    input.addEventListener('input', applyFilters);
    input.addEventListener('change', applyFilters);
  });

  els.resetFilters.addEventListener('click', () => {
    els.searchInput.value = '';
    els.locationFilter.value = 'all';
    els.schoolFilter.value = 'all';
    els.riskFilter.value = 'all';
    applyFilters();
  });

  els.exportCsvBtn.addEventListener('click', exportCsv);
  els.openAddModal.addEventListener('click', () => toggleModal(true));
  els.closeAddModal.addEventListener('click', () => toggleModal(false));
  els.addModal.addEventListener('click', event => {
    if (event.target === els.addModal) toggleModal(false);
  });
  els.addChildForm.addEventListener('submit', addChild);
}

function fillFilters() {
  const unique = key => [...new Set(children.map(child => child[key]))].sort();
  const uniqueHealth = key => [...new Set(children.map(child => child.health[key]))].sort();

  addOptions(els.locationFilter, unique('location'));
  addOptions(els.schoolFilter, unique('schoolStatus'));
  addOptions(els.riskFilter, uniqueHealth('riskLevel'));
}

function addOptions(select, values) {
  values.forEach(value => {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = value;
    select.appendChild(option);
  });
}

function applyFilters() {
  const query = els.searchInput.value.trim().toLowerCase();
  const location = els.locationFilter.value;
  const school = els.schoolFilter.value;
  const risk = els.riskFilter.value;

  filteredChildren = children.filter(child => {
    const matchesSearch = !query ||
      child.name.toLowerCase().includes(query) ||
      child.id.toLowerCase().includes(query) ||
      child.location.toLowerCase().includes(query);
    const matchesLocation = location === 'all' || child.location === location;
    const matchesSchool = school === 'all' || child.schoolStatus === school;
    const matchesRisk = risk === 'all' || child.health.riskLevel === risk;
    return matchesSearch && matchesLocation && matchesSchool && matchesRisk;
  });

  if (!filteredChildren.some(child => child.id === selectedId)) selectedId = null;
  render();
}

function render() {
  renderStats();
  renderTable();
  renderDetail();
}

function renderStats() {
  const total = filteredChildren.length;
  const outSchool = filteredChildren.filter(child => child.schoolStatus === 'خارج المدرسة' || child.schoolStatus === 'بانتظار تسجيل').length;
  const referrals = filteredChildren.filter(child => child.health.referralNeeded).length;
  const documented = filteredChildren.filter(child => child.documentation.digitalFile === 'مكتمل').length;
  const avgProgress = total ? Math.round(filteredChildren.reduce((sum, child) => sum + child.education.progress, 0) / total) : 0;

  const stats = [
    { label: 'إجمالي الأطفال', value: total, note: 'حسب الفلتر الحالي' },
    { label: 'خارج المسار المدرسي', value: outSchool, note: 'خارج المدرسة أو بانتظار تسجيل' },
    { label: 'متوسط التقدم', value: `${avgProgress}%`, note: 'في الجلسات التعليمية' },
    { label: 'تحويلات صحية', value: referrals, note: 'تحتاج متابعة طبية' },
    { label: 'ملفات مكتملة', value: documented, note: 'ملف رقمي جاهز' }
  ];

  els.statsGrid.innerHTML = stats.map(stat => `
    <article class="stat-card">
      <span>${stat.label}</span>
      <strong>${stat.value}</strong>
      <small>${stat.note}</small>
    </article>
  `).join('');
}

function renderTable() {
  els.resultCount.textContent = `${filteredChildren.length} سجل`;

  if (!filteredChildren.length) {
    els.table.innerHTML = `<tr><td colspan="6" class="muted">لا توجد نتائج مطابقة للفلاتر الحالية.</td></tr>`;
    return;
  }

  els.table.innerHTML = filteredChildren.map(child => `
    <tr class="${child.id === selectedId ? 'active' : ''}" data-id="${child.id}">
      <td class="child-cell"><strong>${child.name}</strong><small>${child.id} • ${child.gender}</small></td>
      <td>${child.age}</td>
      <td>${child.location}<br><small class="muted">${child.country} - ${child.city}</small></td>
      <td>
        <span class="badge primary">${child.schoolStatus}</span>
        <div class="progress" aria-label="نسبة التقدم"><span style="width:${child.education.progress}%"></span></div>
      </td>
      <td>${riskBadge(child.health.riskLevel)}</td>
      <td>${fileBadge(child.documentation.digitalFile)}</td>
    </tr>
  `).join('');

  [...els.table.querySelectorAll('tr[data-id]')].forEach(row => {
    row.addEventListener('click', () => {
      selectedId = row.dataset.id;
      render();
    });
  });
}

function renderDetail() {
  const child = children.find(item => item.id === selectedId);
  if (!child) {
    els.detail.className = 'empty-state';
    els.detail.innerHTML = `<span>اختر سجلًا من الجدول</span><p>ستظهر هنا بطاقة الطفل، التوصية التعليمية، والتنبيه الصحي.</p>`;
    return;
  }

  els.detail.className = '';
  const initials = child.name.split(' ').map(part => part[0]).join('').slice(0, 2);
  const healthAlertClass = child.health.riskLevel === 'مرتفع' ? 'alert danger' : 'alert';
  const referralText = child.health.referralNeeded ? 'يوصى بتحويل الحالة للمتابعة الطبية.' : 'لا توجد إحالة طبية عاجلة حسب الفحص الأولي.';

  els.detail.innerHTML = `
    <div class="profile-head">
      <div class="avatar">${initials}</div>
      <div>
        <h3>${child.name}</h3>
        <p>${child.id} • ${child.age} سنوات • ${child.location}</p>
      </div>
    </div>

    <div class="detail-block">
      <h4>التعليم</h4>
      <div class="kv">
        <div><span>مستوى AI</span><strong>${child.education.aiLevel}</strong></div>
        <div><span>التقدم</span><strong>${child.education.progress}%</strong></div>
        <div><span>قراءة</span><strong>${child.education.literacyScore}/100</strong></div>
        <div><span>رياضيات</span><strong>${child.education.mathScore}/100</strong></div>
      </div>
      <p><strong>التوصية:</strong> ${child.education.recommendation}</p>
      <p><strong>آخر درس:</strong> ${child.education.lastLesson}</p>
    </div>

    <div class="detail-block">
      <h4>الصحة الأولية</h4>
      <div class="${healthAlertClass}">${riskBadge(child.health.riskLevel)} ${referralText}</div>
      <div class="kv" style="margin-top:.7rem">
        <div><span>العين</span><strong>${child.health.eye}</strong></div>
        <div><span>الجلد</span><strong>${child.health.skin}</strong></div>
        <div><span>التغذية</span><strong>${child.health.nutrition}</strong></div>
        <div><span>آخر فحص</span><strong>${child.health.lastCheck}</strong></div>
      </div>
    </div>

    <div class="detail-block">
      <h4>الملف الرقمي</h4>
      <div class="kv">
        <div><span>الموافقة</span><strong>${child.documentation.consent ? 'موجودة' : 'غير موجودة'}</strong></div>
        <div><span>الوثائق</span><strong>${child.documentation.documents}</strong></div>
        <div><span>حالة الملف</span><strong>${child.documentation.digitalFile}</strong></div>
        <div><span>ولي الأمر</span><strong>${child.guardian}</strong></div>
      </div>
      <div class="qr-box" title="${child.documentation.qrToken}" aria-label="رمز QR تجريبي"></div>
      <p><strong>ملاحظة:</strong> ${child.notes}</p>
    </div>
  `;
}

function riskBadge(risk) {
  const classes = { 'منخفض': 'success', 'متوسط': 'warning', 'مرتفع': 'danger' };
  return `<span class="badge ${classes[risk] || ''}">${risk}</span>`;
}

function fileBadge(status) {
  const classes = { 'مكتمل': 'success', 'بحاجة مراجعة': 'warning', 'غير منشأ': 'danger' };
  return `<span class="badge ${classes[status] || ''}">${status}</span>`;
}

function toggleModal(open) {
  els.addModal.classList.toggle('open', open);
  els.addModal.setAttribute('aria-hidden', String(!open));
}

function addChild(event) {
  event.preventDefault();
  const form = new FormData(event.target);
  const nextNumber = children.length + 1;
  const id = `FB-2026-${String(nextNumber).padStart(4, '0')}`;
  const riskLevel = form.get('riskLevel');

  const child = {
    id,
    name: form.get('name'),
    age: Number(form.get('age')),
    gender: form.get('gender'),
    country: 'الأردن',
    city: 'تجريبي',
    location: form.get('location'),
    guardian: 'ولي أمر مسجل',
    phone: '+962-79-XXXXXXX',
    schoolStatus: form.get('schoolStatus'),
    education: {
      literacyScore: 45,
      mathScore: 40,
      aiLevel: 'مبتدئ',
      lastLesson: 'تقييم أولي',
      progress: 0,
      attendanceSessions: 0,
      recommendation: 'جلسة تقييم أولى'
    },
    health: {
      eye: 'بانتظار فحص',
      skin: 'بانتظار فحص',
      nutrition: 'بانتظار فحص',
      riskLevel,
      referralNeeded: riskLevel === 'مرتفع',
      lastCheck: 'لم يتم بعد'
    },
    documentation: {
      consent: true,
      documents: 'وثائق ناقصة',
      digitalFile: 'بحاجة مراجعة',
      qrToken: 'QR-' + id.replaceAll('-', '')
    },
    notes: 'سجل تجريبي أضيف من الواجهة.'
  };

  children.unshift(child);
  selectedId = id;
  refillDynamicFilters();
  applyFilters();
  event.target.reset();
  toggleModal(false);
}

function refillDynamicFilters() {
  const currentLocation = els.locationFilter.value;
  const currentSchool = els.schoolFilter.value;
  const currentRisk = els.riskFilter.value;

  els.locationFilter.innerHTML = '<option value="all">كل المواقع</option>';
  els.schoolFilter.innerHTML = '<option value="all">كل الحالات</option>';
  els.riskFilter.innerHTML = '<option value="all">كل المستويات</option>';
  fillFilters();

  if ([...els.locationFilter.options].some(opt => opt.value === currentLocation)) els.locationFilter.value = currentLocation;
  if ([...els.schoolFilter.options].some(opt => opt.value === currentSchool)) els.schoolFilter.value = currentSchool;
  if ([...els.riskFilter.options].some(opt => opt.value === currentRisk)) els.riskFilter.value = currentRisk;
}

function exportCsv() {
  const header = ['id','name','age','gender','location','schoolStatus','progress','riskLevel','referralNeeded','digitalFile'];
  const rows = filteredChildren.map(child => [
    child.id,
    child.name,
    child.age,
    child.gender,
    child.location,
    child.schoolStatus,
    child.education.progress,
    child.health.riskLevel,
    child.health.referralNeeded ? 'yes' : 'no',
    child.documentation.digitalFile
  ]);

  const csv = [header, ...rows]
    .map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(','))
    .join('\n');

  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'futurebus-filtered-data.csv';
  link.click();
  URL.revokeObjectURL(url);
}

init();
